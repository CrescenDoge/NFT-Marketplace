# swagger_client.TokenApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_all_token_ids**](TokenApi.md#get_all_token_ids) | **GET** /nft/{address} | Retrieves the unique NFTs inside a given contract
[**get_contract_nft_transfers**](TokenApi.md#get_contract_nft_transfers) | **GET** /nft/{address}/transfers | Gets NFT transfers of a given contract
[**get_erc721_metadata**](TokenApi.md#get_erc721_metadata) | **GET** /erc721/{address}/metadata | Gets token metadata
[**get_nft_metadata**](TokenApi.md#get_nft_metadata) | **GET** /nft/{address}/metadata | Gets the global metadata for a given contract
[**get_nft_owners**](TokenApi.md#get_nft_owners) | **GET** /nft/{address}/owners | Gets the owners of the NFTs of a given contract
[**get_token_allowance**](TokenApi.md#get_token_allowance) | **GET** /erc20/{address}/allowance | Gets the amount which the spender is allowed to withdraw from the owner.
[**get_token_id_metadata**](TokenApi.md#get_token_id_metadata) | **GET** /nft/{address}/{token_id} | Gets the NFT with the given id of a given contract
[**get_token_id_owners**](TokenApi.md#get_token_id_owners) | **GET** /nft/{address}/{token_id}/owners | Gets the owners of NFTs for a given contract
[**get_token_metadata**](TokenApi.md#get_token_metadata) | **GET** /erc20/metadata | Gets token metadata
[**get_token_metadata_by_symbol**](TokenApi.md#get_token_metadata_by_symbol) | **GET** /erc20/metadata/symbols | Gets token metadata
[**get_token_price**](TokenApi.md#get_token_price) | **GET** /erc20/{address}/price | Gets token price
[**get_wallet_token_id_transfers**](TokenApi.md#get_wallet_token_id_transfers) | **GET** /nft/{address}/{token_id}/transfers | Gets NFT transfers of a given contract

# **get_all_token_ids**
> NftCollection get_all_token_ids(address, chain=chain, format=format, offset=offset, limit=limit, order=order)

Retrieves the unique NFTs inside a given contract

Gets data, including metadata (where available), for all token ids for the given contract address. * Results are sorted by the block the token id was minted (descending) and limited to 100 per page by default * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | If the order should be Ascending or Descending based on the blocknumber on which the NFT was minted. Allowed values: \"ASC\", \"DESC\" (optional)

try:
    # Retrieves the unique NFTs inside a given contract
    api_response = api_instance.get_all_token_ids(address, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_all_token_ids: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| If the order should be Ascending or Descending based on the blocknumber on which the NFT was minted. Allowed values: \&quot;ASC\&quot;, \&quot;DESC\&quot; | [optional] 

### Return type

[**NftCollection**](NftCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_contract_nft_transfers**
> NftTransferCollection get_contract_nft_transfers(address, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets NFT transfers of a given contract

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"block_number\", \"block_number.ASC\", \"block_number.DESC\", Example 2: \"block_number and contract_type\", \"block_number.ASC,contract_type.DESC\" (optional)

try:
    # Gets NFT transfers of a given contract
    api_response = api_instance.get_contract_nft_transfers(address, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_contract_nft_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;block_number\&quot;, \&quot;block_number.ASC\&quot;, \&quot;block_number.DESC\&quot;, Example 2: \&quot;block_number and contract_type\&quot;, \&quot;block_number.ASC,contract_type.DESC\&quot; | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_erc721_metadata**
> list[Erc721Metadata] get_erc721_metadata(address, chain=chain, provider_url=provider_url)

Gets token metadata

Returns metadata (name, symbol) for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets token metadata
    api_response = api_instance.get_erc721_metadata(address, chain=chain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_erc721_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**list[Erc721Metadata]**](Erc721Metadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_metadata**
> NftContractMetadata get_nft_metadata(address, chain=chain)

Gets the global metadata for a given contract

Gets the contract level metadata (name, symbol, base token uri) for the given contract * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)

try:
    # Gets the global metadata for a given contract
    api_response = api_instance.get_nft_metadata(address, chain=chain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 

### Return type

[**NftContractMetadata**](NftContractMetadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_owners**
> NftOwnerCollection get_nft_owners(address, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets the owners of the NFTs of a given contract

Gets all owners of NFT items within a given contract collection * Use after /nft/contract/{token_address} to find out who owns each token id in a collection * Make sure to include a sort parm on a column like block_number_minted for consistent pagination results * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"name\", \"name.ASC\", \"name.DESC\", Example 2: \"Name and Symbol\", \"name.ASC,symbol.DESC\" (optional)

try:
    # Gets the owners of the NFTs of a given contract
    api_response = api_instance.get_nft_owners(address, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_owners: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;name\&quot;, \&quot;name.ASC\&quot;, \&quot;name.DESC\&quot;, Example 2: \&quot;Name and Symbol\&quot;, \&quot;name.ASC,symbol.DESC\&quot; | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_allowance**
> Erc20Allowance get_token_allowance(address, owner_address, spender_address, chain=chain, provider_url=provider_url)

Gets the amount which the spender is allowed to withdraw from the owner.

Gets the amount which the spender is allowed to withdraw from the spender

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
owner_address = 'owner_address_example' # str | The address of the token owner
spender_address = 'spender_address_example' # str | The address of the token spender
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets the amount which the spender is allowed to withdraw from the owner.
    api_response = api_instance.get_token_allowance(address, owner_address, spender_address, chain=chain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_allowance: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **owner_address** | **str**| The address of the token owner | 
 **spender_address** | **str**| The address of the token spender | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**Erc20Allowance**](Erc20Allowance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_id_metadata**
> Nft get_token_id_metadata(address, token_id, chain=chain, format=format)

Gets the NFT with the given id of a given contract

Gets data, including metadata (where available), for the given token id of the given contract address. * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)

try:
    # Gets the NFT with the given id of a given contract
    api_response = api_instance.get_token_id_metadata(address, token_id, chain=chain, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_id_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]

### Return type

[**Nft**](Nft.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_id_owners**
> NftOwnerCollection get_token_id_owners(address, token_id, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets the owners of NFTs for a given contract

Gets all owners of NFT items within a given contract collection * Use after /nft/contract/{token_address} to find out who owns each token id in a collection * Make sure to include a sort parm on a column like block_number_minted for consistent pagination results * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"name\", \"name.ASC\", \"name.DESC\", Example 2: \"Name and Symbol\", \"name.ASC,symbol.DESC\" (optional)

try:
    # Gets the owners of NFTs for a given contract
    api_response = api_instance.get_token_id_owners(address, token_id, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_id_owners: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;name\&quot;, \&quot;name.ASC\&quot;, \&quot;name.DESC\&quot;, Example 2: \&quot;Name and Symbol\&quot;, \&quot;name.ASC,symbol.DESC\&quot; | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_metadata**
> list[Erc20Metadata] get_token_metadata(addresses, chain=chain, subdomain=subdomain, provider_url=provider_url)

Gets token metadata

Returns metadata (name, symbol, decimals, logo) for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
addresses = ['addresses_example'] # list[str] | The addresses to get metadata for
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets token metadata
    api_response = api_instance.get_token_metadata(addresses, chain=chain, subdomain=subdomain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **addresses** | [**list[str]**](str.md)| The addresses to get metadata for | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**list[Erc20Metadata]**](Erc20Metadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_metadata_by_symbol**
> list[Erc20Metadata] get_token_metadata_by_symbol(symbols, chain=chain, subdomain=subdomain)

Gets token metadata

Returns metadata (name, symbol, decimals, logo) for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
symbols = ['symbols_example'] # list[str] | The symbols to get metadata for
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)

try:
    # Gets token metadata
    api_response = api_instance.get_token_metadata_by_symbol(symbols, chain=chain, subdomain=subdomain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_metadata_by_symbol: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbols** | [**list[str]**](str.md)| The symbols to get metadata for | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 

### Return type

[**list[Erc20Metadata]**](Erc20Metadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_price**
> Erc20Price get_token_price(address, chain=chain, provider_url=provider_url, exchange=exchange)

Gets token price

Returns the price nominated in the native token and usd for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
exchange = 'exchange_example' # str | The factory name or address of the token exchange (optional)

try:
    # Gets token price
    api_response = api_instance.get_token_price(address, chain=chain, provider_url=provider_url, exchange=exchange)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_price: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **exchange** | **str**| The factory name or address of the token exchange | [optional] 

### Return type

[**Erc20Price**](Erc20Price.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_wallet_token_id_transfers**
> NftTransferCollection get_wallet_token_id_transfers(address, token_id, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets NFT transfers of a given contract

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"block_number\", \"block_number.ASC\", \"block_number.DESC\", Example 2: \"block_number and contract_type\", \"block_number.ASC,contract_type.DESC\" (optional)

try:
    # Gets NFT transfers of a given contract
    api_response = api_instance.get_wallet_token_id_transfers(address, token_id, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_wallet_token_id_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;block_number\&quot;, \&quot;block_number.ASC\&quot;, \&quot;block_number.DESC\&quot;, Example 2: \&quot;block_number and contract_type\&quot;, \&quot;block_number.ASC,contract_type.DESC\&quot; | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

