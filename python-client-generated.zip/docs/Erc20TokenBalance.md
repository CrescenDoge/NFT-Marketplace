# Erc20TokenBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the token contract | 
**name** | **str** | The name of the token Contract | 
**symbol** | **str** | The symbol of the NFT contract | 
**logo** | **str** | The logo of the token | [optional] 
**thumbnail** | **str** | The thumbnail of the logo | [optional] 
**decimals** | **str** | The number of decimals on of the token | 
**balance** | **str** | Timestamp of when the contract was last synced with the node | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

