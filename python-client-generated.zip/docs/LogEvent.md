# LogEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_hash** | **str** | The transaction hash | 
**address** | **str** | The address of the contract | 
**block_timestamp** | **str** | The block timestamp | 
**block_number** | **str** | The block number | 
**block_hash** | **str** | The block hash | 
**data** | **object** | The content of the event | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

