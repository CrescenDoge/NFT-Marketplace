# BlockTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hash** | **str** | The hash of the transaction | 
**nonce** | **str** | The nonce | 
**transaction_index** | **str** |  | 
**from_address** | **str** | The from address | 
**to_address** | **str** | The to address | 
**value** | **str** | The value sent | 
**gas** | **str** |  | [optional] 
**gas_price** | **str** | The gas price | 
**input** | **str** |  | 
**receipt_cumulative_gas_used** | **str** |  | 
**receipt_gas_used** | **str** |  | 
**receipt_contract_address** | **str** |  | [optional] 
**receipt_root** | **str** |  | [optional] 
**receipt_status** | **str** |  | 
**block_timestamp** | **str** | The block timestamp | 
**block_number** | **str** | The block number | 
**block_hash** | **str** | The hash of the block | 
**logs** | [**list[Log]**](Log.md) | The logs of the transaction | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

