# NftTransfer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the contract of the NFT | 
**token_id** | **str** | The token id of the NFT | 
**from_address** | **str** | The address that sent the NFT | [optional] 
**to_address** | **str** | The address that recieved the NFT | 
**amount** | **str** | The number of tokens transferred | [optional] 
**contract_type** | **str** | The type of NFT contract standard | 
**block_number** | **str** | The blocknumber of the transaction | 
**block_timestamp** | **str** | The block timestamp | 
**block_hash** | **str** | The block hash of the transaction | 
**transaction_hash** | **str** | The transaction hash | 
**transaction_type** | **str** | The transaction type | [optional] 
**transaction_index** | **str** | The transaction index | [optional] 
**log_index** | **int** | The log index | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

