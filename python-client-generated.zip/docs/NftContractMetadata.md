# NftContractMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the token contract | 
**name** | **str** | The name of the token Contract | 
**abi** | **str** | The abi of the token Contract | [optional] 
**supports_token_uri** | **int** | value -1 if the contract does not support token_uri | [optional] 
**synced_at** | **str** | Timestamp of when the contract was last synced with the node | [optional] 
**symbol** | **str** | The symbol of the NFT contract | 
**contract_type** | **str** | The type of NFT contract | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

