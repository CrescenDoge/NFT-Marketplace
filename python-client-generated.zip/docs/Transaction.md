# Transaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hash** | **str** | The hash of the transaction | 
**nonce** | **str** | The nonce of the transaction | 
**transaction_index** | **str** | The transaction index | 
**from_address** | **str** | The sender | 
**to_address** | **str** | The recipient | 
**value** | **str** | The value that was transfered (in wei) | 
**gas** | **str** | The gas of the transaction | 
**gas_price** | **str** | The gas price | 
**input** | **str** | The input | 
**receipt_cumulative_gas_used** | **str** | The receipt cumulative gas used | 
**receipt_gas_used** | **str** | The receipt gas used | 
**receipt_contract_address** | **str** | The receipt contract address | 
**receipt_root** | **str** | The receipt root | 
**receipt_status** | **str** | The receipt status | 
**block_timestamp** | **str** | The block timestamp | 
**block_number** | **str** | The block number | 
**block_hash** | **str** | The block hash | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

