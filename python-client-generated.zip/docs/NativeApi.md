# swagger_client.NativeApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_block**](NativeApi.md#get_block) | **GET** /block/{block_number_or_hash} | Gets block contents by block hash
[**get_contract_events**](NativeApi.md#get_contract_events) | **POST** /{address}/events | Gets events by topic

# **get_block**
> Block get_block(block_number_or_hash, chain=chain, subdomain=subdomain)

Gets block contents by block hash

Gets the contents of a block by block hash

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
block_number_or_hash = 'block_number_or_hash_example' # str | The block hash or block number
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)

try:
    # Gets block contents by block hash
    api_response = api_instance.get_block(block_number_or_hash, chain=chain, subdomain=subdomain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_block: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **block_number_or_hash** | **str**| The block hash or block number | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 

### Return type

[**Block**](Block.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_contract_events**
> list[LogEvent] get_contract_events(body, topic, address, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, offset=offset, limit=limit)

Gets events by topic

Gets events in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
body = NULL # object | Optional description in *Markdown*
topic = 'topic_example' # str | The topic of the event
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
from_block = 56 # int | from_block (optional)
to_block = 56 # int | to_block (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets events by topic
    api_response = api_instance.get_contract_events(body, topic, address, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_contract_events: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**object**](object.md)| Optional description in *Markdown* | 
 **topic** | **str**| The topic of the event | 
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **from_block** | **int**| from_block | [optional] 
 **to_block** | **int**| to_block | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**list[LogEvent]**](LogEvent.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

