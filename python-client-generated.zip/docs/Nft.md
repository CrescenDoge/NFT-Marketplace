# Nft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the contract of the NFT | 
**token_id** | **str** | The token id of the NFT | 
**contract_type** | **str** | The type of NFT contract standard | 
**token_uri** | **str** | The uri to the metadata of the token | [optional] 
**metadata** | **str** | The metadata of the token | [optional] 
**synced_at** | **str** | when the metadata was last updated | [optional] 
**amount** | **str** | The number of this item the user owns (used by ERC1155) | [optional] 
**name** | **str** | The name of the Token contract | 
**symbol** | **str** | The symbol of the NFT contract | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

