# swagger_client.AccountApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_historical_nft_transfers**](AccountApi.md#get_historical_nft_transfers) | **GET** /{address}/nft/transfers/verbose | Gets NFT transfers of a ERC721 or ERC1155 token
[**get_native_balance**](AccountApi.md#get_native_balance) | **GET** /{address}/balance | Gets native balance for a specific address.
[**get_nf_ts**](AccountApi.md#get_nf_ts) | **GET** /{address}/nft | Gets the NFTs owned by a given address
[**get_nf_ts_for_contract**](AccountApi.md#get_nf_ts_for_contract) | **GET** /{address}/nft/{token_address} | Gets the NFTs owned by a given address
[**get_nft_transfers**](AccountApi.md#get_nft_transfers) | **GET** /{address}/nft/transfers | Gets NFT transfers to and from a given address
[**get_token_balances**](AccountApi.md#get_token_balances) | **GET** /{address}/erc20 | Gets token balances for a specific address.
[**get_token_transfers**](AccountApi.md#get_token_transfers) | **GET** /{address}/erc20/transfers | Gets erc 20 token transactions
[**get_transactions**](AccountApi.md#get_transactions) | **GET** /{address} | Gets native transactions

# **get_historical_nft_transfers**
> list[HistoricalNftTransfer] get_historical_nft_transfers(address, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, offset=offset, limit=limit)

Gets NFT transfers of a ERC721 or ERC1155 token

Gets NFT token transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
from_block = 56 # int | from_block (optional)
to_block = 56 # int | to_block (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets NFT transfers of a ERC721 or ERC1155 token
    api_response = api_instance.get_historical_nft_transfers(address, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_historical_nft_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **from_block** | **int**| from_block | [optional] 
 **to_block** | **int**| to_block | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**list[HistoricalNftTransfer]**](HistoricalNftTransfer.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_native_balance**
> NativeBalance get_native_balance(address, chain=chain, provider_url=provider_url, to_block=to_block)

Gets native balance for a specific address.

Gets native balance for a specific address

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address for which the native balance will be checked
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
to_block = 1.2 # float | The block number on which the balances should be checked (optional)

try:
    # Gets native balance for a specific address.
    api_response = api_instance.get_native_balance(address, chain=chain, provider_url=provider_url, to_block=to_block)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_native_balance: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address for which the native balance will be checked | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **to_block** | **float**| The block number on which the balances should be checked | [optional] 

### Return type

[**NativeBalance**](NativeBalance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nf_ts**
> NftOwnerCollection get_nf_ts(address, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets the NFTs owned by a given address

Gets NFTs owned by the given address * The response will include status [SYNCED/SYNCING] based on the contracts being indexed. * Use the token_address param to get results for a specific contract only * Note results will include all indexed NFTs * Any request which includes the token_address param will start the indexing process for that NFT collection the very first time it is requested 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The owner of a given token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"name\", \"name.ASC\", \"name.DESC\", Example 2: \"Name and Symbol\", \"name.ASC,symbol.DESC\" (optional)

try:
    # Gets the NFTs owned by a given address
    api_response = api_instance.get_nf_ts(address, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nf_ts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The owner of a given token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;name\&quot;, \&quot;name.ASC\&quot;, \&quot;name.DESC\&quot;, Example 2: \&quot;Name and Symbol\&quot;, \&quot;name.ASC,symbol.DESC\&quot; | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nf_ts_for_contract**
> NftOwnerCollection get_nf_ts_for_contract(address, token_address, chain=chain, format=format, offset=offset, limit=limit, order=order)

Gets the NFTs owned by a given address

Gets NFTs owned by the given address * Use the token_address param to get results for a specific contract only * Note results will include all indexed NFTs * Any request which includes the token_address param will start the indexing process for that NFT collection the very first time it is requested 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The owner of a given token
token_address = 'token_address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"name\", \"name.ASC\", \"name.DESC\", Example 2: \"Name and Symbol\", \"name.ASC,symbol.DESC\" (optional)

try:
    # Gets the NFTs owned by a given address
    api_response = api_instance.get_nf_ts_for_contract(address, token_address, chain=chain, format=format, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nf_ts_for_contract: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The owner of a given token | 
 **token_address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;name\&quot;, \&quot;name.ASC\&quot;, \&quot;name.DESC\&quot;, Example 2: \&quot;Name and Symbol\&quot;, \&quot;name.ASC,symbol.DESC\&quot; | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_transfers**
> NftTransferCollection get_nft_transfers(address, chain=chain, format=format, direction=direction, offset=offset, limit=limit, order=order)

Gets NFT transfers to and from a given address

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The sender or recepient of the transfer
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
direction = 'both' # str | The transfer direction (optional) (default to both)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"token_address\", \"token_address.ASC\", \"token_address.DESC\", Example 2: \"token_address and token_id\", \"token_address.ASC,token_id.DESC\" (optional)

try:
    # Gets NFT transfers to and from a given address
    api_response = api_instance.get_nft_transfers(address, chain=chain, format=format, direction=direction, offset=offset, limit=limit, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nft_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The sender or recepient of the transfer | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **direction** | **str**| The transfer direction | [optional] [default to both]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;token_address\&quot;, \&quot;token_address.ASC\&quot;, \&quot;token_address.DESC\&quot;, Example 2: \&quot;token_address and token_id\&quot;, \&quot;token_address.ASC,token_id.DESC\&quot; | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_balances**
> list[Erc20TokenBalance] get_token_balances(address, chain=chain, subdomain=subdomain, to_block=to_block)

Gets token balances for a specific address.

Gets token balances for a specific address

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address for which token balances will be checked
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
to_block = 1.2 # float | The block number on which the balances should be checked (optional)

try:
    # Gets token balances for a specific address.
    api_response = api_instance.get_token_balances(address, chain=chain, subdomain=subdomain, to_block=to_block)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_token_balances: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address for which token balances will be checked | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **to_block** | **float**| The block number on which the balances should be checked | [optional] 

### Return type

[**list[Erc20TokenBalance]**](Erc20TokenBalance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_transfers**
> list[Erc20Transaction] get_token_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, offset=offset, limit=limit)

Gets erc 20 token transactions

Gets ERC20 token transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
from_block = 56 # int | from_block (optional)
to_block = 56 # int | to_block (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets erc 20 token transactions
    api_response = api_instance.get_token_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_token_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **from_block** | **int**| from_block | [optional] 
 **to_block** | **int**| to_block | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**list[Erc20Transaction]**](Erc20Transaction.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_transactions**
> TransactionCollection get_transactions(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, offset=offset, limit=limit)

Gets native transactions

Gets native transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
from_block = 56 # int | from_block (optional)
to_block = 56 # int | to_block (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets native transactions
    api_response = api_instance.get_transactions(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_transactions: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **from_block** | **int**| from_block | [optional] 
 **to_block** | **int**| to_block | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**TransactionCollection**](TransactionCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

