# Block

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **str** | The block timestamp | 
**number** | **str** | The block number | 
**hash** | **str** | The block hash | 
**parent_hash** | **str** | The block hash of the parent block | 
**nonce** | **str** | The nonce | 
**sha3_uncles** | **str** |  | 
**logs_bloom** | **str** |  | 
**transactions_root** | **str** |  | 
**state_root** | **str** |  | 
**receipts_root** | **str** |  | 
**miner** | **str** | The address of the miner | 
**difficulty** | **str** | The difficulty of the block | 
**total_difficulty** | **str** | The total difficulty | 
**size** | **str** | The block size | 
**extra_data** | **str** |  | 
**gas_limit** | **str** | The gas limit | 
**gas_used** | **str** | The gas used | 
**transaction_count** | **str** | The number of transactions in the block | 
**transactions** | [**list[BlockTransaction]**](BlockTransaction.md) | The transactions in the block | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

